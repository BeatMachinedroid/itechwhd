function getCurrentTime() {
    return Math.round(new Date().getTime() / 1000);
}
